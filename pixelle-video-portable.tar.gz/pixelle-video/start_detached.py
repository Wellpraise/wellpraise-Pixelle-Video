#!/usr/bin/env python3
"""持久化启动 Pixelle-Video 服务。

WorkBuddy 会话结束后，Bash 工具里 `nohup ... &` 启动的后台进程会被回收。
本脚本用 subprocess.Popen(start_new_session=True) 让两个服务脱离当前会话
(相当于 setsid)，会话结束后仍继续存活。

同时在这里统一做环境清理，等价于 start.sh 里的逻辑：
  - 清 PYTHONPATH（沙箱 sitecustomize shim 会导致 mkdir(exist_ok=True) 崩溃）
  - 清所有 *PROXY（避免 OpenAI SDK 把 Agnes 请求绕到沙箱代理）
  - 补齐 PATH（homebrew 的 ffmpeg 等）

用法：python3 start_detached.py   （由 start.sh 调用，也可直接运行）
"""
import os
import subprocess
import time
import urllib.request

PROJECT_DIR = "/Users/inbest/Desktop/AI/workbuddy/pixelle-video"
API_PORT = 8000
WEB_PORT = 8504
API_LOG = "/tmp/pixelle-api.log"
WEB_LOG = "/tmp/pixelle-web.log"
VENV_PY = os.path.join(PROJECT_DIR, ".venv/bin/python")


def clean_env() -> dict:
    env = dict(os.environ)
    # 清掉 WorkBuddy 注入的沙箱 shim
    env.pop("PYTHONPATH", None)
    # 清掉所有代理变量，让 Agnes 客户端直连
    for k in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY",
              "ALL_PROXY", "all_proxy", "NO_PROXY", "no_proxy"):
        env.pop(k, None)
    # 补齐 PATH：homebrew bin + venv 自带 imageio-ffmpeg 二进制目录
    extra = [
        "/usr/local/bin",
        "/opt/homebrew/bin",
        os.path.join(PROJECT_DIR,
                     ".venv/lib/python3.13/site-packages/imageio_ffmpeg/binaries"),
    ]
    cur = env.get("PATH", "").split(":")
    cur = [d for d in cur if d]
    for d in extra:
        if d not in cur:
            cur.insert(0, d)
    env["PATH"] = ":".join(cur)
    return env


def health(url: str) -> bool:
    try:
        r = urllib.request.urlopen(url, timeout=3)
        return r.status == 200
    except Exception:
        return False


def main() -> None:
    env = clean_env()
    # 先精确杀掉本项目旧进程：
    # 1) 命令行匹配（pkill -f，兼容相对/绝对路径启动）
    subprocess.run(["pkill", "-f", "pixelle-video/api/app.py"],
                   env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-f", "pixelle-video/web/app.py"],
                   env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # 2) 端口匹配兜底（最可靠：直接杀占用 8000/8504 的监听进程，
    #    防止旧进程因 pkill 命令行不匹配而残留、导致新进程抢不到端口）
    for port in (API_PORT, WEB_PORT):
        try:
            pids = subprocess.run(
                ["lsof", "-nP", f"-tiTCP:{port}", "-sTCP:LISTEN"],
                env=env, capture_output=True, text=True, timeout=10
            ).stdout.split()
            for pid in pids:
                pid = pid.strip()
                if pid:
                    print(f"⚠️  结束占用端口 {port} 的旧进程 pid={pid}")
                    os.kill(int(pid), 15)
        except Exception:
            pass
    time.sleep(2)
    # 再确认端口已释放，没释放就强杀
    for port in (API_PORT, WEB_PORT):
        try:
            pids = subprocess.run(
                ["lsof", "-nP", f"-tiTCP:{port}", "-sTCP:LISTEN"],
                env=env, capture_output=True, text=True, timeout=10
            ).stdout.split()
            for pid in pids:
                if pid.strip():
                    os.kill(int(pid), 9)
        except Exception:
            pass
        time.sleep(1)

    api = subprocess.Popen(
        [VENV_PY, "api/app.py", "--host", "127.0.0.1", "--port", str(API_PORT)],
        cwd=PROJECT_DIR, env=env,
        stdout=open(API_LOG, "w"), stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    web = subprocess.Popen(
        [VENV_PY, "-m", "streamlit", "run", "web/app.py",
         "--server.port", str(WEB_PORT), "--server.address", "127.0.0.1",
         "--server.headless", "true"],
        cwd=PROJECT_DIR, env=env,
        stdout=open(WEB_LOG, "w"), stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    print(f"✅ API 服务启动 (pid {api.pid}): http://127.0.0.1:{API_PORT}")
    print(f"✅ Web UI 启动 (pid {web.pid}): http://127.0.0.1:{WEB_PORT}")

    # 等待服务就绪
    time.sleep(5)
    api_ok = health(f"http://127.0.0.1:{API_PORT}/")
    web_ok = health(f"http://127.0.0.1:{WEB_PORT}/")
    print(f"健康检查 -> api:{'OK' if api_ok else 'FAIL'}  web:{'OK' if web_ok else 'FAIL'}")
    print("两个服务已脱离本会话（独立 session），会话结束后仍会存活。")


if __name__ == "__main__":
    main()
