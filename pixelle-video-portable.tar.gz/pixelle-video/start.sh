#!/bin/bash
# Pixelle-Video 一键启动脚本
# 使用方法: ./start.sh
#
# 端口说明（避免与本机其他项目冲突）:
#   - 8000: Pixelle API
#   - 8504: Pixelle Web UI
#   8501 = MoneyPrinter-Agnes, 8502/8503 = MoneyPrinterTurbo-main，勿占用

PROJECT_DIR="/Users/inbest/Desktop/AI/workbuddy/pixelle-video"
API_LOG="/tmp/pixelle-api.log"
WEB_LOG="/tmp/pixelle-web.log"
API_PORT=8000
WEB_PORT=8504

cd "$PROJECT_DIR"

# 关键：WorkBuddy CLI 会通过 PYTHONPATH 注入 sitecustomize 沙箱 shim，
# 该 shim 会让 mkdir(exist_ok=True) 在目录已存在时误抛 PermissionError(EEXIST)，
# 导致 Pixelle 初始化 output/ 目录时崩溃。启动前清掉即可正常读写文件。
unset PYTHONPATH

# 关键：WorkBuddy 终端会注入 HTTP(S)_PROXY 指向沙箱代理(如 127.0.0.1:49368)，
# 而 OpenAI SDK 默认 trust_env=True 会尊重它，导致对 apihub.agnes-ai.com 的
# 请求被绕到该代理、转发不可靠，报 "openai.APIConnectionError: Connection error."。
# 清掉所有代理变量，让 LLM/图像/视频客户端直连 Agnes。
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY all_proxy NO_PROXY no_proxy

# 关键：确保 ffmpeg 所在目录在 PATH。WorkBuddy 终端的 PATH 被裁剪，
# 可能缺 /usr/local/bin(homebrew)，导致 video.py 的 shutil.which("ffmpeg") 返回 None，
# 报 "FFmpeg not found"。这里幂等地把常见 homebrew bin 与 venv 自带 imageio-ffmpeg
# 二进制目录补进去（系统终端本就正常，不影响）。
for d in /usr/local/bin /opt/homebrew/bin \
         "$PROJECT_DIR/.venv/lib/python3.13/site-packages/imageio_ffmpeg/binaries"; do
  case ":$PATH:" in
    *":$d:"*) ;;
    *) PATH="$d:$PATH";;
  esac
done
export PATH

echo "🚀 启动 Pixelle-Video..."
echo ""

# 停止本项目旧进程（按项目路径精确匹配，避免误杀其他项目的 streamlit）
pkill -f "pixelle-video/api/app.py" 2>/dev/null
pkill -f "pixelle-video/web/app.py" 2>/dev/null
sleep 2

# 端口占用检查
if lsof -nP -iTCP:$API_PORT -sTCP:LISTEN >/dev/null 2>&1; then
  echo "⚠️  端口 $API_PORT 已被占用，请先释放或改端口"
fi
if lsof -nP -iTCP:$WEB_PORT -sTCP:LISTEN >/dev/null 2>&1; then
  echo "⚠️  端口 $WEB_PORT 已被占用，请先释放或改端口"
fi

# 启动 API 服务 + Web UI
# 关键：用 start_detached.py（Python start_new_session=True，等价 setsid）让服务脱离
# 当前会话，避免 WorkBuddy 会话结束后被回收；同时在该脚本里统一做环境清理
# （清 PYTHONPATH / 清 *PROXY / 补 PATH）。
echo "🚀 启动 Pixelle-Video（脱离会话，持久存活）..."
python3 "$PROJECT_DIR/start_detached.py"

sleep 3
echo ""
echo "========================================"
echo "   ✅ Pixelle-Video 已启动"
echo "========================================"
echo ""
echo "📍 访问地址："
echo "  • Web UI:  http://127.0.0.1:$WEB_PORT"
echo "  • API:     http://127.0.0.1:$API_PORT"
echo "  • API 文档: http://127.0.0.1:$API_PORT/docs"
echo ""
echo "📄 配置文件: config.yaml"
echo "📄 日志: $API_LOG / $WEB_LOG"
echo "========================================"
