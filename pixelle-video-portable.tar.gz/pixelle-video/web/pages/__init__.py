"""Pages for web interface"""

