"""Agnes AI 视频生成客户端

Agnes 的视频接口为 ``POST /v1/videos``，需要 ``mode`` 参数（服务端未公开取值枚举），
返回异步任务后需要轮询结果。本客户端对任务 ID、状态字段、结果 URL 做宽容解析，
并在 ``mode`` 被拒时自动尝试其它候选值。

支持模型（由 /v1/models 接口实时返回，2.5 为最新）：
    - agnes-video-2.5-flash
    - agnes-video-2.5
    - agnes-video-v2.0
"""

import base64
import os
import re
import time
from typing import Any, Optional

import httpx

DEFAULT_BASE_URL = "https://apihub.agnes-ai.com/v1"
DEFAULT_MODEL = "agnes-video-2.5-flash"

# mode 合法取值未公开，按探测结果排序；被拒时依次降级尝试
MODE_CANDIDATES = ["t2v", "i2v", "standard", "fast", "text_to_video", "image_to_video"]

SUCCESS_STATES = {"succeeded", "success", "completed", "complete", "done", "finished", "succeed"}
FAILED_STATES = {"failed", "fail", "error", "cancelled", "canceled", "rejected", "expired"}
PENDING_STATES = {"queued", "pending", "processing", "running", "in_progress", "waiting", "submitted"}


def _walk(node: Any):
    """深度遍历 dict / list"""
    if isinstance(node, dict):
        for key, value in node.items():
            yield key, value
            yield from _walk(value)
    elif isinstance(node, list):
        for item in node:
            yield from _walk(item)


def _extract_id(data: Any) -> Optional[str]:
    for key, value in _walk(data):
        if key.lower() in {"id", "task_id", "taskid", "video_id", "videoid", "job_id", "jobid", "request_id"}:
            if isinstance(value, (str, int)) and str(value).strip():
                return str(value)
    return None


def _extract_status(data: Any) -> Optional[str]:
    for key, value in _walk(data):
        if key.lower() in {"status", "state", "task_status", "taskstatus"}:
            if isinstance(value, str):
                return value.strip().lower()
    return None


def _extract_url(data: Any) -> Optional[str]:
    """找到响应里的视频地址"""
    preferred, fallback = None, None
    for key, value in _walk(data):
        if not isinstance(value, str) or not value.startswith("http"):
            continue
        lowered = value.lower().split("?")[0]
        key_lower = key.lower()
        if key_lower in {"url", "video_url", "videourl", "download_url", "result_url", "output"}:
            preferred = preferred or value
            if lowered.endswith((".mp4", ".mov", ".webm")):
                return value
        if lowered.endswith((".mp4", ".mov", ".webm")):
            fallback = fallback or value
    return preferred or fallback


class VideoAgnes:
    """Agnes 视频生成客户端"""

    def __init__(self,
                 api_key: str = None,
                 base_url: str = None,
                 local_proxy: str = None,
                 timeout: float = 300.0,
                 poll_interval: float = 10.0,
                 max_wait: float = 900.0,
                 mode: Optional[str] = None):
        self.api_key = api_key or os.getenv("AGNES_API_KEY")
        if not self.api_key:
            raise RuntimeError("AGNES_API_KEY 未配置，无法使用 Agnes 视频生成")
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.poll_interval = poll_interval
        self.max_wait = max_wait
        self.proxy = local_proxy or None
        # Agnes /v1/videos 的 mode 取值未公开；配置了就用配置值，否则自动尝试候选值
        self.default_mode = (mode or os.getenv("AGNES_VIDEO_MODE") or "").strip() or None

    def _client(self) -> httpx.Client:
        return httpx.Client(proxy=self.proxy, timeout=self.timeout) if self.proxy else httpx.Client(timeout=self.timeout)

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _encode_image(self, image_path: Optional[str]) -> Optional[str]:
        if not image_path or not os.path.exists(image_path):
            return None
        with open(image_path, "rb") as f:
            data = base64.b64encode(f.read()).decode("utf-8")
        ext = os.path.splitext(image_path)[1].lower().replace(".", "") or "png"
        if ext not in {"png", "jpg", "jpeg", "webp"}:
            ext = "png"
        return f"data:image/{ext};base64,{data}"

    def _create_task(self, client: httpx.Client, payload: dict) -> dict:
        response = client.post(f"{self.base_url}/videos", headers=self._headers(), json=payload)
        try:
            data = response.json()
        except Exception:
            data = {"raw": response.text}

        if response.status_code >= 400 or (isinstance(data, dict) and data.get("error")):
            message = ""
            if isinstance(data, dict):
                message = str((data.get("error") or {}).get("message") or data.get("message") or "")
            raise RuntimeError(f"Agnes 视频接口错误 ({response.status_code}): {message or response.text[:200]}")

        # 服务端以 code=invalid_request 表示参数错误
        if isinstance(data, dict) and data.get("code"):
            raise RuntimeError(f"Agnes 视频接口错误: {data.get('message') or data.get('code')}")

        return data

    def _poll(self, client: httpx.Client, task_id: str) -> str:
        deadline = time.time() + self.max_wait
        last_status = None
        while time.time() < deadline:
            response = client.get(f"{self.base_url}/videos/{task_id}", headers=self._headers())
            try:
                data = response.json()
            except Exception:
                data = {}

            url = _extract_url(data)
            status = _extract_status(data)
            last_status = status or last_status

            if status in SUCCESS_STATES or (status is None and url):
                if url:
                    return url
                if status in SUCCESS_STATES:
                    raise RuntimeError(f"Agnes 任务完成但未返回视频地址: {str(data)[:200]}")
            if status in FAILED_STATES:
                raise RuntimeError(f"Agnes 视频生成失败: {str(data)[:300]}")

            time.sleep(self.poll_interval)

        raise RuntimeError(f"Agnes 视频生成超时（{self.max_wait}s，最后状态: {last_status}）")

    def _download(self, client: httpx.Client, url: str, save_path: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        with client.stream("GET", url) as response:
            response.raise_for_status()
            with open(save_path, "wb") as f:
                for chunk in response.iter_bytes():
                    f.write(chunk)
        return save_path

    def generate_video(self,
                       prompt: str,
                       image_path: Optional[str] = None,
                       save_path: str = "video.mp4",
                       model: str = None,
                       duration: int = 5,
                       video_ratio: str = "16:9",
                       resolution: Optional[str] = None,
                       mode: Optional[str] = None,
                       **_ignored) -> str:
        """生成视频并下载到 save_path"""
        model = model or DEFAULT_MODEL
        encoded_image = self._encode_image(image_path)
        mode = mode or self.default_mode

        # 有参考图优先图生视频，否则文生视频
        if mode:
            candidates = [mode] + [m for m in MODE_CANDIDATES if m != mode]
        elif encoded_image:
            candidates = ["i2v", "t2v"] + [m for m in MODE_CANDIDATES if m not in {"i2v", "t2v"}]
        else:
            candidates = list(MODE_CANDIDATES)

        last_error = None
        with self._client() as client:
            # 可选字段：Agnes 会拒绝不认识的字段，逐个按需剔除后重试
            optional_fields: dict = {}
            if duration:
                optional_fields["duration"] = int(duration)
            if video_ratio:
                optional_fields["ratio"] = video_ratio
                optional_fields["aspect_ratio"] = video_ratio
            if resolution:
                optional_fields["resolution"] = resolution
            if encoded_image:
                optional_fields["image"] = encoded_image

            for candidate in candidates:
                payload: dict = {"model": model, "prompt": prompt, "mode": candidate}
                payload.update(optional_fields)

                data = None
                for _ in range(len(optional_fields) + 2):
                    try:
                        data = self._create_task(client, payload)
                        break
                    except RuntimeError as exc:
                        last_error = exc
                        message = str(exc)
                        if "invalid mode" in message.lower():
                            break  # data 仍为 None，换下一个 mode
                        match = re.search(r"([\w.]+) is not an allowed request field", message)
                        if match and match.group(1) in payload:
                            payload.pop(match.group(1))
                            continue
                        raise

                if data is None:
                    continue

                url = _extract_url(data)
                task_id = _extract_id(data)

                if url:
                    return self._download(client, url, save_path)
                if task_id:
                    url = self._poll(client, task_id)
                    return self._download(client, url, save_path)

                last_error = RuntimeError(f"无法从 Agnes 响应中解析任务 ID 或地址: {str(data)[:200]}")

        raise RuntimeError(f"Agnes 视频生成失败，最后错误: {last_error}")
