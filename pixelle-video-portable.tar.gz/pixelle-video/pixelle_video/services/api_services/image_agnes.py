"""Agnes AI 图片生成客户端

Agnes 提供 OpenAI 兼容协议（supported_endpoint_types: ["openai"]），
文生图走 ``POST /v1/images/generations``。

支持模型（由 /v1/models 接口实时返回，2.5 为最新）：
    - agnes-image-2.5-flash
    - agnes-image-2.1-flash
    - agnes-image-2.0-flash
"""

import os
import time
import uuid

import httpx
from openai import OpenAI

try:
    from .image_processor import ImageProcessor
except ImportError:  # pragma: no cover - 独立运行时的兜底
    from image_processor import ImageProcessor


class ImageAgnes:
    """Agnes 图片生成客户端（OpenAI 兼容 Images API）"""

    DEFAULT_BASE_URL = "https://apihub.agnes-ai.com/v1"
    DEFAULT_MODEL = "agnes-image-2.5-flash"

    # Agnes 图片接口接受的尺寸有限，这里把任意分辨率收敛到最接近的标准尺寸
    SUPPORTED_SIZES = ("1024x1024", "1024x1536", "1536x1024")

    def __init__(self,
                 api_key: str = None,
                 base_url: str = None,
                 local_proxy: str = None,
                 timeout: float = 300.0):
        self.api_key = api_key or os.getenv("AGNES_API_KEY")
        if not self.api_key:
            raise RuntimeError("AGNES_API_KEY 未配置，无法使用 Agnes 图片生成")
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.timeout = timeout

        kwargs = {"api_key": self.api_key, "timeout": timeout, "base_url": self.base_url}
        if local_proxy:
            kwargs["http_client"] = httpx.Client(proxy=local_proxy, timeout=timeout)
        self.client = OpenAI(**kwargs)
        self.image_processor = ImageProcessor(local_proxy=local_proxy)

    @classmethod
    def normalize_size(cls, size: str) -> str:
        """把 WxH / W*H 尺寸收敛到 Agnes 支持的标准尺寸。"""
        if not size:
            return "1024x1024"
        normalized = str(size).replace("*", "x").lower()
        if normalized in cls.SUPPORTED_SIZES:
            return normalized
        try:
            width, height = (int(part) for part in normalized.split("x")[:2])
        except (ValueError, AttributeError):
            return "1024x1024"
        if width == height:
            return "1024x1024"
        return "1536x1024" if width > height else "1024x1536"

    def generate_image(self,
                       prompt: str,
                       size: str = "1024x1024",
                       model: str = None,
                       save_dir: str = None,
                       **_ignored) -> str:
        """生成一张图片并返回本地路径（无 save_dir 时返回远端 URL）"""
        model = model or self.DEFAULT_MODEL
        size = self.normalize_size(size)

        response = self.client.images.generate(
            model=model,
            prompt=prompt,
            size=size,
            n=1,
        )

        if not response or not response.data:
            raise RuntimeError("Agnes API 返回数据为空")

        img_data = response.data[0]

        # 1. Base64 格式
        b64 = getattr(img_data, "b64_json", None)
        if b64:
            if not save_dir:
                return b64
            os.makedirs(save_dir, exist_ok=True)
            file_path = os.path.join(save_dir, f"agnes_{int(time.time())}_{uuid.uuid4().hex[:6]}.png")
            with open(file_path, "wb") as f:
                f.write(__import__("base64").b64decode(b64))
            return file_path

        # 2. URL 格式
        url = getattr(img_data, "url", None)
        if url:
            if not save_dir:
                return url
            os.makedirs(save_dir, exist_ok=True)
            file_path = os.path.join(save_dir, f"agnes_{int(time.time())}_{uuid.uuid4().hex[:6]}.png")
            if self.image_processor.download_image(url, file_path):
                return file_path
            return url

        raise RuntimeError("Agnes 响应中未找到 url 或 b64_json")
