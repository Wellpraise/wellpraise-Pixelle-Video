# Pixelle-Video 配置总结

> 本文档包含所有配置信息和使用方法，复制后随时可用。

---

## 📍 服务地址

| 服务 | 地址 | 状态 |
|------|------|------|
| Web UI | http://localhost:8501 | ✅ 可用 |
| API | http://localhost:8000 | ✅ 可用 |
| API文档 | http://localhost:8000/docs | ✅ 可用 |

---

## 🔧 已配置项

### LLM 配置
- **服务**: Agnes AI
- **模型**: agnes-2.5-flash
- **API Key**: `wk-3UTcT7xM290dZ8vo4p8Hu48XYjGmwU7LotOieGbrzMuMn90I`
- **Base URL**: https://apihub.agnes-ai.com/v1

### 端口配置
- API 端口: 8000
- Web UI 端口: 8501

---

## 🚀 启动命令（复制使用）

### 方式一：手动启动
```bash
cd /Users/inbest/Desktop/AI/workbuddy/pixelle-video

# 启动 API 服务（终端1）
.venv/bin/python api/app.py --host 0.0.0.0 --port 8000

# 启动 Web UI（终端2）
.venv/bin/python -m streamlit run web/app.py --server.port 8501 --server.address 0.0.0.0 --server.headless true
```

### 方式二：后台启动（推荐）
```bash
cd /Users/inbest/Desktop/AI/workbuddy/pixelle-video

# 后台启动 API
.venv/bin/python api/app.py --host 0.0.0.0 --port 8000 &

# 后台启动 Web UI
.venv/bin/python -m streamlit run web/app.py --server.port 8501 --server.address 0.0.0.0 --server.headless true &
```

### 方式三：使用启动脚本
```bash
cd /Users/inbest/Desktop/AI/workbuddy/pixelle-video
./start.sh
```

---

## 📁 关键文件位置

| 文件 | 路径 |
|------|------|
| 项目目录 | `/Users/inbest/Desktop/AI/workbuddy/pixelle-video/` |
| 配置文件 | `config.yaml` |
| 输出目录 | `output/` |
| 虚拟环境 | `.venv/` |
| 配置文档 | `README_CONFIG.md` |
| 启动指南 | `快速启动指南.md` |

---

## ⚠️ 可选配置（按需）

### 图像/视频生成服务

如果需要生成图片或视频，需要配置以下服务之一：

**1. RunningHub（推荐）**
- 官网: https://runninghub.cn/
- 注册获取 API Key
- 在 Web UI → ⚙️ 系统配置 中填入

**2. 本地 ComfyUI**
- 需要 NVIDIA 显卡 6GB+ 显存
- 官网: https://github.com/comfyanonymous/ComfyUI

**3. 其他可用模型**
- Agnes AI 提供: agnes-image-2.0-flash, agnes-image-2.1-flash, agnes-video-v2.0

---

## 📝 配置更新

如需修改配置，编辑文件：
```
/Users/inbest/Desktop/AI/workbuddy/pixelle-video/config.yaml
```

---

## 🔒 安全提示

- 请勿将 config.yaml 提交到 Git
- API Key 请妥善保管
- 建议将 config.yaml 添加到 .gitignore

---

## ✅ 验证服务

```bash
# 检查 API
curl http://localhost:8000/health

# 检查 Web UI
curl http://localhost:8501/

# 查看端口占用
lsof -i :8000 -i :8501
```

---

最后更新: 2026-08-09
