#!/bin/bash
# Pixelle-Video 一键启动脚本
# 使用方法: ./start.sh

PROJECT_DIR="/Users/inbest/Desktop/AI/workbuddy/pixelle-video"
API_LOG="/tmp/pixelle-api.log"
WEB_LOG="/tmp/pixelle-web.log"

cd "$PROJECT_DIR"

echo "🚀 启动 Pixelle-Video..."
echo ""

# 停止旧进程
pkill -f "api/app.py" 2>/dev/null
pkill -f "streamlit run" 2>/dev/null
sleep 2

# 启动 API 服务
nohup .venv/bin/python api/app.py --host 0.0.0.0 --port 8000 > "$API_LOG" 2>&1 &
echo "✅ API 服务启动: http://localhost:8000"

# 启动 Web UI
nohup .venv/bin/python -m streamlit run web/app.py --server.port 8501 --server.address 0.0.0.0 --server.headless true > "$WEB_LOG" 2>&1 &
echo "✅ Web UI 启动: http://localhost:8501"

sleep 3
echo ""
echo "========================================"
echo "   ✅ Pixelle-Video 已启动"
echo "========================================"
echo ""
echo "📍 访问地址："
echo "  • Web UI:  http://localhost:8501"
echo "  • API:     http://localhost:8000"
echo ""
echo "📄 配置文件: config.yaml"
echo "========================================"
