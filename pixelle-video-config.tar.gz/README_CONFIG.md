# Pixelle-Video 配置说明

## 📍 服务地址

| 服务 | 地址 | 状态 |
|------|------|------|
| Web UI | http://localhost:8501 | ✅ 运行中 |
| API | http://localhost:8000 | ✅ 运行中 |
| API文档 | http://localhost:8000/docs | ✅ 可用 |

## 🔧 LLM配置（已完成）

- **服务**: Agnes AI
- **模型**: agnes-2.5-flash
- **API Key**: `wk-3UTcT7xM290dZ8vo4p8Hu48XYjGmwU7LotOieGbrzMuMn90I`
- **Base URL**: https://apihub.agnes-ai.com/v1

## 🚀 启动命令

```bash
cd /Users/inbest/Desktop/AI/workbuddy/pixelle-video

# 启动 API 服务
.venv/bin/python api/app.py --host 0.0.0.0 --port 8000

# 启动 Web UI（另一个终端）
.venv/bin/python -m streamlit run web/app.py --server.port 8501 --server.address 0.0.0.0 --server.headless true
```

## 📁 项目路径

- 项目目录: `/Users/inbest/Desktop/AI/workbuddy/pixelle-video/`
- 配置文件: `/Users/inbest/Desktop/AI/workbuddy/pixelle-video/config.yaml`
- 输出目录: `/Users/inbest/Desktop/AI/workbuddy/pixelle-video/output/`
- 虚拟环境: `/Users/inbest/Desktop/AI/workbuddy/pixelle-video/.venv/`

## ⚠️ 可选配置（按需配置）

### 图像/视频生成服务

如果需要生成图片或视频，需要配置以下之一：

**1. RunningHub（推荐，无需本地显卡）**
- 官网: https://runninghub.cn/
- 注册获取 API Key
- 在 Web UI 的「系统配置」中填入

**2. 本地 ComfyUI（需要 NVIDIA 显卡 6GB+）**
- 官网: https://github.com/comfyanonymous/ComfyUI
- 需要本地部署并配置

### TTS 语音合成
- ✅ 已内置 Edge-TTS，无需额外配置

## 🔑 其他可用模型

Agnes AI 提供的其他模型：
- agnes-2.0-flash
- agnes-2.5-pro
- agnes-2.5-pro-alpha
- agnes-image-2.0-flash（图像生成）
- agnes-image-2.1-flash（图像生成）
- agnes-video-v2.0（视频生成）

## ❌ 已知限制

- 图像生成、视频生成功能需要 RunningHub API Key 才能使用
- 目前仅文字生成功能可用

## 📝 更新配置

如需修改配置，编辑文件：
```
/Users/inbest/Desktop/AI/workbuddy/pixelle-video/config.yaml
```

## 🔒 安全提示

- 请勿将 config.yaml 提交到 Git
- API Key 请妥善保管

---
最后更新: 2026-08-09
